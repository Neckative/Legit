package com.example.test;

import androidx.appcompat.app.AppCompatActivity;

import android.content.Intent;
import android.os.Bundle;
import android.view.View;
import android.widget.Button;
import android.widget.EditText;
import android.widget.TextView;

public class MainActivity extends AppCompatActivity {

    public static int stat = 0;

    private int counter = 0;

    private EditText inputUser;
    private EditText inputPassword;
    private Button btn2Home;

    private TextView txtNotifiacation;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main);

        inputUser = (EditText) findViewById(R.id.Username);
        inputPassword = (EditText) findViewById(R.id.Password);
        btn2Home = (Button) findViewById(R.id.button3);
        txtNotifiacation = (TextView) findViewById(R.id.textView3);

        txtNotifiacation.setVisibility(View.GONE);
        txtNotifiacation.setText("Invalid Username or Password");

        btn2Home.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                validate(inputUser.getText().toString().toLowerCase(), inputPassword.getText().toString().toLowerCase());
            }
        });
    }
    private void validate(String userName, String userPassword){
        if((userName.equals("admin")) && (userPassword.equals("1234"))){
            Intent intent = new Intent(MainActivity.this, HomeActivity.class);
            startActivity(intent);
            stat = 4;
        } else if (userName.equals("neckkatie") && (userPassword.equals("1234"))){
            txtNotifiacation.setVisibility(View.GONE);
            Intent intent = new Intent(MainActivity.this, HomeActivity.class);
            startActivity(intent);
            stat = 5;
        }else if (userName.equals("pro") && (userPassword.equals("1234"))){
            txtNotifiacation.setVisibility(View.GONE);
            Intent intent = new Intent(MainActivity.this, HomeActivity.class);
            startActivity(intent);
            stat = 3;
        }else if (userName.equals("user") && (userPassword.equals("1234"))){
            txtNotifiacation.setVisibility(View.GONE);
            Intent intent = new Intent(MainActivity.this, HomeActivity.class);
            startActivity(intent);
            stat = 2;
        }else if (userName.equals("guest") && (userPassword.equals("1234"))){
            txtNotifiacation.setVisibility(View.GONE);
            Intent intent = new Intent(MainActivity.this, HomeActivity.class);
            startActivity(intent);
            stat = 1;
        }else{
            counter++;
            txtNotifiacation.setVisibility(View.VISIBLE);
            txtNotifiacation.setText("You have " + String.valueOf(5-counter) + " attempts left");
            if(counter == 5){
                txtNotifiacation.setText("Try again later!");
                btn2Home.setEnabled(false);
            }
        }
    }
}
